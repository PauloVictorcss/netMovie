package br.com.netMovie.calculos;

public interface Classificavel {

    int getClassificacao();
}
